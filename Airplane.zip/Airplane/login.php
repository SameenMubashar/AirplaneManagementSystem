<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="CSS/style.css">
	<link rel="stylesheet" type="text/css" href="CSS/sign.css">
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<a class="navbar-brand" href="#">Skyways</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
			<div class="navbar-nav ml-auto">
				<a class="nav-item nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a>
				<a class="nav-item nav-link" href="view.php">View Flight Schedule</a>
				<a class="nav-item nav-link" href="reserve.php">Reserve Flight</a>
				<a class="nav-item nav-link" href="cancel.php">Cancel Flight</a>
				<a class="nav-item nav-link" href="login.php">Login</a>
			</div>
		</div>
	</nav>
	<section class="my-4">
		<div class="container">
			<div class="row">
				<div class="col-sm">
				</div>
				<div class="col-sm">
					<div class="signup-form">
						<form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data">
							<h2>Login</h2>
							<p class="hint-text">Enter Login Details</p>
							<div class="form-group">
								<input type="email" class="form-control" name="email" placeholder="Email" required="required">
							</div>
							<div class="form-group">
								<input type="password" class="form-control" name="pass" placeholder="Password" required="required">
							</div>
							<div class="form-group">
								<button type="submit" name="submit" class="btn btn-success btn-lg btn-block">Login</button>
							</div>
							<div class="text-center">Don't have an account? <a href="signup.php">Register Here</a></div>
						</form>
					</div>
				</div>
				<div class="col-sm">
				</div>
			</div>
		</div>
	</section>
	<?php
	$conn=mysqli_connect("localhost","root","","airport");
	if($conn->connect_error)
	{
		die("Connection failed:".$conn-> connect_error);
	}
	if(isset($_POST['submit']))
	{
		$email=mysqli_real_escape_string($conn,$_POST['email']);
		$password=mysqli_real_escape_string($conn,$_POST['pass']);
		$email_search="SELECT * FROM passenger WHERE email ='$email'";
		$v_query=mysqli_query($conn,$email_search);

		$email_count = mysqli_num_rows($v_query);
		if($email_count)
		{
			$email_pass=mysqli_fetch_assoc($v_query);
			$dp_pass=$email_pass['password'];
			$email_name="SELECT name FROM passenger WHERE email ='$email'";
			$n_query=mysqli_query($conn,$email_name);
			$_SESSION['name']=$n_query;
			if($dp_pass===$password)
			{
				echo "login sucessfull";
				?>
				<script>
					location.replace("index.php");
				</script>
				<?php
			}
			else
			{
				echo "Incorrect Password";
			}
		}
		else
		{
			echo "Invalid Email";
		}
	}


	?>

	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>