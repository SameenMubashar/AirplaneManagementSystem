<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="CSS/style.css">
	<link rel="stylesheet" type="text/css" href="CSS/sign.css">
</head>
<body>
	<div class="container">
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
			<a class="navbar-brand" href="#">Skyways</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
				<div class="navbar-nav ml-auto">
					<a class="nav-item nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a>
					<a class="nav-item nav-link" href="view.php">View Flight Schedule</a>
					<a class="nav-item nav-link" href="reserve.php">Reserve Flight</a>
					<a class="nav-item nav-link" href="cancel.php">Cancel Flight</a>
					<?php if(isset($_SESSION['name'])):?>
						<a class="nav-item nav-link" href="logout.php" style="text-decoration:none">logout</a>'
					<?php else: ?> 
						<a class="nav-item nav-link" href="login.php" style="text-decoration:none">logout</a>';
					<?php endif; ?>
				</div>
			</div>
		</nav>

		<section class="my-4">
			<div class="container">
				<div class="row">
					<div class="col-sm">
					</div>
					<div class="col-sm">
						<div class="signup-form">
							<form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data">
								<h2>Register</h2>
								<p class="hint-text">Create your account</p>
								<div class="form-group">
									<div class="row">
										<div class="col"><input type="text" class="form-control" name="name" placeholder="Name" required="required"></div>
									</div>        	
								</div>
								<div class="form-group">
									<input type="email" class="form-control" name="email" placeholder="Email" required="required">
								</div>
								<div class="form-group">
									<input type="password" class="form-control" name="pass" placeholder="Password" required="required">
								</div>
								<div class="form-group">
									<input type="password" class="form-control" name="cpass" placeholder="Confirm Password" required="required">
								</div>
								<div class="form-group">
									<p>Gender</p>
									<input type="radio" name="gender" value="male"> Male<br>
									<input type="radio" name="gender" value="female"> Female<br>
									<input type="radio" name="gender" value="other"> Other
								</div>
								<div class="form-group">
									<input type="text" class="form-control" name="address" placeholder="Type Address" required="required">
								</div>

								<div class="form-group">
									<input type="text" class="form-control" name="date" placeholder="Enter Date" required="required">
								</div>
								
								
								<div class="form-group">
									<input type="text" class="form-control" name="month" placeholder="Enter Month" required="required">
									
								</div>
								
								<div class="form-group">
									<input type="text" class="form-control" name="year" placeholder="Enter Year" required="required">
								</div>
								
								<div class="form-group">
									<button type="submit" name="submit" class="btn btn-success btn-lg btn-block">Register Now</button>
								</div>
								<div class="text-center">Already have an account? <a href="login.php">Sign in</a></div>
							</form>

						</div>
					</div>
					<div class="col-sm">
					</div>
				</div>
			</div>
		</section>

		<?php
		$conn=mysqli_connect("localhost","root","","airport");
		if($conn->connect_error)
		{
			die("Connection failed:".$conn-> connect_error);
		}
		if(isset($_POST['submit']))
		{
			$name=mysqli_real_escape_string($conn, $_POST['name']);
			$email=mysqli_real_escape_string($conn,$_POST['email']);
			$password=mysqli_real_escape_string($conn,$_POST['pass']);
			$cpassword=mysqli_real_escape_string($conn,$_POST['cpass']);
			$sex=mysqli_real_escape_string($conn,$_POST['gender']);
			$address=mysqli_real_escape_string($conn,$_POST['address']);
			$date=mysqli_real_escape_string($conn,$_POST['date']);
			$month=mysqli_real_escape_string($conn,$_POST['month']);
			$year=mysqli_real_escape_string($conn,$_POST['year']);

			$emailquery="SELECT * FROM passenger WHERE email ='$email'";
			$query=mysqli_query($conn,$emailquery);

			$emailcount = mysqli_num_rows($query);
			if($emailcount>0)
			{
				echo "Email already exists";
			}
			else
			{
				if($password===$cpassword)
				{
					$insertquery = "INSERT INTO passenger( name, email, password, sex, address, date, month, year) VALUES ('$name','$email','$password','$sex','$address','$date','$month','$year')";
					$iquery=mysqli_query($conn,$insertquery);
					if($iquery)
					{
						?>
						<script>
						alert("Insertion Successfull");</script>
						<?php
						?>
				<script>
					location.replace("login.php");
				</script>
				<?php
					}
					else
					{
						?>
						<script>
						alert("Insertion Unsuccessfull");</script>
						<?php
					}
				}

				else
				{
					echo "password are not matching";
				}
			}
		}
		$conn->close();
		?>
		<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
	</div>
	<?php
	session_destroy();
	?>
</body>
</html>