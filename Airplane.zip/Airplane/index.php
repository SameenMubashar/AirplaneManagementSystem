<?php
session_start();
if ($_SESSION['name'])
{
  echo "Loged in ";
}
else
{
  header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="CSS/style.css">
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Skyways</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav ml-auto">
        <a class="nav-item nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a>
        <a class="nav-item nav-link" href="view.php">View Flight Schedule</a>
        <a class="nav-item nav-link" href="reserve.php">Reserve Flight</a>
        <a class="nav-item nav-link" href="cancel.php">Cancel Flight</a>
        <?php if(isset($_SESSION['name'])):?>
          <a class="nav-item nav-link" href="logout.php" style="text-decoration:none">logout</a>'
        <?php else: ?> 
         <a class="nav-item nav-link" href="login.php" style="text-decoration:none">logout</a>';
       <?php endif; ?>

     </div>

   </div>
 </nav>

 <div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="Images/lounge.jpeg" alt="Los Angeles" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Luxury Lounge</h3>
        <p>Feel At Home!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="Images/place.jpeg" alt="Chicago" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Around The World Experience</h3>
        <p>We had such a great time!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="Images/runway.jpeg" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Premium Services</h3>
        <p>24/7 Services!</p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

<section class="my-5">
	<div class = "py-5">
		<h3 class="text-center">About Us</h3>
	</div>
	<div class="container-fluid">
		<div class = "row">
			<div class="col-lg-6">
				<img src="Images/plane.jpeg" class="img-fluid">
			</div>
			<div class="col-lg-6">
				<h2>WANNA TRAVEL</h2>
				<p>Finding the perfect flight is the key to a stress-free trip. Help your users search and book flights on over 500 airlines around the world, see useful information like baggage allowance and ancillary prices, and use filters and calendar view to find the flight that's right for them.Quick access and easy-to-use REST/JSON APIs mean you can start building your booking engine in minutes. Find documentation, tools and resources to get started and benefit from over 30 years of Amadeus travel industry experience to start growing your booking business quickly.</p>
			</div>

		</div>
	</div>
</section>



<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>