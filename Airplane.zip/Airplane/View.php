<<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>
	</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="CSS/style.css">
	<style>
		table {
			border-collapse: collapse;
			width: 100%;
		}

		th, td {
			text-align: left;
			padding: 8px;
		}

		tr:nth-child(even){background-color: #f2f2f2}

		th {
			background-color: #04AA6D;
			color: white;
		}
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<a class="navbar-brand" href="#">Skyways</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
			<div class="navbar-nav ml-auto">
				<a class="nav-item nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a>
				<a class="nav-item nav-link" href="view.php">View Flight Schedule</a>
				<a class="nav-item nav-link" href="reserve.php">Reserve Flight</a>
				<a class="nav-item nav-link" href="cancel.php">Cancel Flight</a>
				<?php if(isset($_SESSION['name'])):?>
					<a class="nav-item nav-link" href="logout.php" style="text-decoration:none">logout</a>'
				<?php else: ?> 
					<a class="nav-item nav-link" href="login.php" style="text-decoration:none">logout</a>';
				<?php endif; ?>
			</div>
		</div>
	</nav>
	<section class="my-4">
		<div class = "py-4">
			<h3 class="text-center">Flight Schedule</h3>
		</div>
		<table>
			<th>Flight Number</th>
			<th>Airplane Number</th>
			<th>Destination</th>
			<th>Departure Time</th>
			<th>Take off Location</th>
			<th>Status</th>
			<th>Date</th>
			<th>Month</th>
			<th>Mode</th>
			<?php
			$conn=mysqli_connect("localhost","root","","airport");
			if($conn->connect_error)
			{
				die("Connection failed:".$conn-> connect_error);
			}
			$sql="SELECT * FROM flights";
			$result=$conn->query($sql);

			if ($result -> num_rows > 0) {
				while ($row = $result -> fetch_assoc() ) {
		// code...
					echo "<tr><td>".$row["flightNum"]."</td><td>".$row["airplaneNum"]."</td><td>".$row["destination"]."</td><td>".$row["departureTime"]."</td><td>".$row["takeOffLocation"]."</td><td>".$row["status"]."</td><td>".$row["date"]."</td><td>".$row["month"]."</td><td>".$row["mode"]."</td></tr>";
				}
				echo "</table>";
			}
			else
			{
				echo "0 result";
			}
			$conn->close();
			?>



		</table>
</section>
		<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
	</body>
	</html>
