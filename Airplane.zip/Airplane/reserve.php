
<?php
session_start();
if ($_SESSION['name'])
{
  echo "Loged in ";
}
else
{
  header('location:login.php');
}
ini_set('log_errors','On');
ini_set('display_errors','Off');
ini_set('error_reporting', E_ALL );
define('WP_DEBUG', false);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="CSS/style.css">
  <style>
    table {
      border-collapse: collapse;
      width: 100%;
    }

    th, td {
      text-align: left;
      padding: 8px;
    }

    tr:nth-child(even){background-color: #f2f2f2}

    th {
      background-color: #04AA6D;
      color: white;
    }
  </style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Skyways</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav ml-auto">
        <a class="nav-item nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a>
        <a class="nav-item nav-link" href="view.php">View Flight Schedule</a>
        <a class="nav-item nav-link" href="reserve.php">Reserve Flight</a>
        <a class="nav-item nav-link" href="cancel.php">Cancel Flight</a>
        <?php if(isset($_SESSION['name'])):?>
          <a class="nav-item nav-link" href="logout.php" style="text-decoration:none">logout</a>'
        <?php else: ?> 
         <a class="nav-item nav-link" href="login.php" style="text-decoration:none">logout</a>';
       <?php endif; ?>
     </div>
   </div>
 </nav>
 <section class="my-4">
  <div class="container">
    <div class="row">
      <div class="col-sm">
      </div>
      <div class="col-sm">
        <div class="signup-form">
          <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data">
            <h2>Search Flight</h2>
            <p class="hint-text">Enter Details of flight</p>
            <div class="form-group">
              <input type="text" class="form-control" name="date" placeholder="Date" required="required">
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="Takeoff" placeholder="Take Off Location" required="required">
            </div>
            <div class="form-group">
              <button type="submit" name="submit" class="btn btn-success btn-lg btn-block">Search</button>
            </div>
          </form>
        </div>
      </div>
      <div class="col-sm">
      </div>
    </div>
  </div>
</section>
<section class="my-4">
  <div class = "py-4">
    <h3 class="text-center">Flight Schedule</h3>
  </div>
  <table>
    <th>Flight Number</th>
    <th>Airplane Number</th>
    <th>Destination</th>
    <th>Departure Time</th>
    <th>Take off Location</th>
    <th>Status</th>
    <th>Date</th>
    <th>Month</th>
    <th>Mode</th>
    <?php
    $conn=mysqli_connect("localhost","root","","airport");
    if($conn->connect_error)
    {
      die("Connection failed:".$conn-> connect_error);
    }
    if(isset($_POST['submit']))
    {
      $date=mysqli_real_escape_string($conn,$_POST['date']);
      $takeofflocation=mysqli_real_escape_string($conn,$_POST['Takeoff']);
      $sqli=("SELECT * FROM flights WHERE date='$date'AND takeOffLocation='$takeofflocation'");
      $results=$conn->query($sqli);

      if ($results -> num_rows > 0) {
        while ($row = $results -> fetch_assoc() ) {
          echo "<tr><td>".$row["flightNum"]."</td><td>".$row["airplaneNum"]."</td><td>".$row["destination"]."</td><td>".$row["departureTime"]."</td><td>".$row["takeOffLocation"]."</td><td>".$row["status"]."</td><td>".$row["date"]."</td><td>".$row["month"]."</td><td>".$row["mode"]."</td></tr>";          
        }
        echo "</table>";
      }
      else
      {
        echo "0 result";
      }
    }
    $conn->close();
    ?>
  </table>
</section>
<section class="my-4">
  <div class="container">
    <div class="row">
      <div class="col-sm">
      </div>
      <div class="col-sm">
        <div class="signup-form">
          <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data">
            <h2>Book Flight</h2>
            <p class="hint-text">Book your flight now</p>
            <div class="form-group">
              <input type="text" class="form-control" name="Cust_Name" placeholder="Enter Your Name Here" required="required">
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="Destination" placeholder="Destination" required="required">
            </div>
            <div class="form-group">
              <input type="number" class="form-control" name="Flightnum" placeholder="Enter Flight Number Here" required="required">
            </div>            
            <div class="form-group">
              <button type="submit" name="Book" class="btn btn-success btn-lg btn-block">Book</button>
            </div>
          </form>
        </div>
      </div>
      <div class="col-sm">
      </div>
    </div>
  </div>
</section>
<?php
$conn=mysqli_connect("localhost","root","","airport");
if($conn->connect_error)
{
  die("Connection failed:".$conn-> connect_error);
}
if(isset($_POST['Book']))
{
  $Flightnum=mysqli_real_escape_string($conn, $_POST['Flightnum']);
  $Cust_name=mysqli_real_escape_string($conn, $_POST['Cust_Name']);
   $destination=mysqli_real_escape_string($conn,$_POST['Destination']);
  $Customer="SELECT   id  FROM passenger WHERE name='$Cust_name'";
  $c_query=mysqli_query($conn,$Customer);
  $matches = cast_query_results($c_query);
  $bookquery="INSERT INTO booking( flightNum, passengerID,Destination ) VALUES (' $Flightnum','$matches','$destination')";
  $b_query=mysqli_query($conn,$bookquery);
  if($b_query)
  {
    ?>
    <script>
    alert("Insertion Successfull");</script>
    <?php
  }
  else
  {
    ?>
    <script>
    alert("Insertion Unsuccessfull");</script>
    <?php
  }
  
}

$conn->close();
function cast_query_results($rs) {
  $fields = mysqli_fetch_fields($rs);
  $data = array();
  $types = array();
  foreach($fields as $field) {
    switch($field->type) {
      case 3:
      $types[$field->name] = 'int';
      break;
      case 4:
      $types[$field->name] = 'float';
      break;
      default:
      $types[$field->name] = 'string';
      break;
    }
  }
  while($row=mysqli_fetch_assoc($rs)) array_push($data,$row);
  for($i=0;$i<count($data);$i++) {
    foreach($types as $name => $type) {
      settype($data[$i][$name], $type);
    }
  }
  return $data;
}
?>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>